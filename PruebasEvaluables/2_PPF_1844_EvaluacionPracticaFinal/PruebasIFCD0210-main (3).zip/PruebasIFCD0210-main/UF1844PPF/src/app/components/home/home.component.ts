import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateurl: './home.component.html'
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
